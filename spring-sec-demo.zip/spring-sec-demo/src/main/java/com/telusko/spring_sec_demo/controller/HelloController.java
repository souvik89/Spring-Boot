package com.telusko.spring_sec_demo.controller;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import jakarta.servlet.http.HttpServletRequest;

@RestController 
public class HelloController {

	@GetMapping("hello") 
	public String greet() {
		// return "Hello World "+request.getSession().getId();
		return "Hello World";
	}

    @GetMapping("about") 
	public String about(HttpServletRequest request) {
		return "About Us!! "+request.getSession().getId();
	}
}