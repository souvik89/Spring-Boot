package com.telusko.spring_boot_rest.aop;

import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.After;
import org.aspectj.lang.annotation.AfterReturning;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

@Component
@Aspect
public class LoggingAspect {

    private static final Logger Logger= LoggerFactory.getLogger(LoggingAspect.class);

    @Before("execution (* com.telusko.spring_boot_rest.service.JobService.*(..))")
    public void logMethodCall(JoinPoint jp) {
        Logger.info("Method Called "+jp.getSignature().getName());
    }



    @After("execution (* com.telusko.spring_boot_rest.service.JobService.*(..))")
    public void logMethodExecuted(JoinPoint jp) {
        Logger.info("Method Executed "+jp.getSignature().getName());
    }

    @AfterReturning("execution (* com.telusko.spring_boot_rest.service.JobService.getJob(..)) || execution(* com.telusko.spring_boot_rest.service.JobService.updateJob(..))")
    public void logMethodExecutedSuccess(JoinPoint jp) {
        Logger.info("Method Executed Successfully "+jp.getSignature().getName());
    }
}
