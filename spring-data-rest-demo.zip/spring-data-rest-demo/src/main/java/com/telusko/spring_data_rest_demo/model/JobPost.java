package com.telusko.spring_data_rest_demo.model;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.stereotype.Component;

import java.util.List;


@Data
@NoArgsConstructor
@AllArgsConstructor
@Entity
public class JobPost {


    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY) // Or your preferred strategy
    private Integer postId;  // Use Integer, NOT int


    private String postProfile;
    private String postDesc;
    private Integer reqExperience;
    private List<String> postTechStack;
}
