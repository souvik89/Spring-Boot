package com.telusko.quizapp.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.telusko.quizapp.dao.QuestionDao;
import com.telusko.quizapp.dao.QuizDao;
import com.telusko.quizapp.model.Question;
import com.telusko.quizapp.model.QuestionWrapper;
import com.telusko.quizapp.model.Quiz;
import com.telusko.quizapp.model.Response;

@Service
public class QuizService {

    @Autowired
    QuizDao quizDao;

    @Autowired
    QuestionDao questionDao;

    public ResponseEntity<String> createQuiz(String category, int numQ, String title) {

            List<Question> questions = questionDao.getRandomQuestionsByCategory(category, numQ);
            Quiz quiz = new Quiz();
            quiz.setTitle(title);
            quiz.setQuestions(questions);
            quizDao.save(quiz);
            return new ResponseEntity<>("Success", HttpStatus.CREATED);

        }

	public ResponseEntity<List<QuestionWrapper>> getQuizQuestions(Integer id) {
        Optional<Quiz> quiz= quizDao.findById(id);
        List<Question> questionFromDB= quiz.get().getQuestions();

        List<QuestionWrapper> questionForUser=new ArrayList<>();
        for(Question q: questionFromDB)
        {
            QuestionWrapper qw= new QuestionWrapper(q.getId(),q.getQuestionTitle(),q.getOption1(),q.getOption2(),q.getOption3(),q.getOption4());
            questionForUser.add(qw);
        }

        return new ResponseEntity<>(questionForUser,HttpStatus.OK); 
    }

     

    public ResponseEntity<Integer> calculateResult(int id, List<Response> responses) {

    Quiz quiz = quizDao.findById(id).orElseThrow(() -> new RuntimeException("Quiz not found"));

    List<Question> questions = quiz.getQuestions();

    int right = 0;

    // for (int i = 0; i < responses.size() && i < questions.size(); i++) {

    //     if (responses.get(i).getResponse().equalsIgnoreCase(questions.get(i).getRightAnswer())) {

    //         right++;
    //     }
    // }

    for (Response response : responses) {

            Question question = questions.stream()
                    .filter(q -> q.getId() == response.getId())
                    .findFirst()
                    .orElse(null);

                if (question != null && response.getResponse().equalsIgnoreCase(question.getRightAnswer())) {

                    right++;
                }
        }

    return new ResponseEntity<>(right, HttpStatus.OK);
    }
}
